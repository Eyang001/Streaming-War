package edu.gatech.streamingwars.systemservices;

import edu.gatech.streamingwars.models.ArchiveData;
import edu.gatech.streamingwars.repositories.ArchiveRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ArchiveService {

    @Autowired
    private ArchiveRepository archiveRepository;

    public ArchiveData archive(ArchiveData archiveData) {
        ArchiveData found = archiveRepository.findByTimestamp(archiveData.getTimestamp());
        if (found != null) {
            return found;
        }
        return archiveRepository.save(archiveData);
    }

    public void purge(String timestamp) {
        Long id = archiveRepository.findIdByTimestamp(timestamp);
        if (id == null) return;
        archiveRepository.deleteById(id);
    }
}
