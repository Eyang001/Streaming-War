package edu.gatech.streamingwars.repositories;

import edu.gatech.streamingwars.models.ArchiveData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ArchiveRepository extends JpaRepository<ArchiveData, Long> {

    @Query("select a from ArchiveData a where a.timestamp = ?1")
    ArchiveData findByTimestamp(String timestamp);

    @Query("select a.id from ArchiveData a where a.timestamp = ?1")
    long findIdByTimestamp(String timestamp);

}
