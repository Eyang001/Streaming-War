// package edu.gatech.streamingwars;
//
//
// import org.springframework.boot.SpringApplication;
// import org.springframework.boot.autoconfigure.SpringBootApplication;
// import org.springframework.web.bind.annotation.CrossOrigin;
// import org.springframework.web.bind.annotation.RestController;
//
// @RestController
// @SpringBootApplication
// @CrossOrigin(origins = "http://localhost:3001")
// public class StreamingwarGateway {
//
//         public static void main(String[] args) {
//             SpringApplication.run(StreamingwarGateway.class, args);
//         }
//
// }
