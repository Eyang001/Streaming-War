package edu.gatech.streamingwars.models;


import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Entity
public class ArchiveData {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    long id;

    @NotNull
    private String timestamp;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "archiveData")
    private List<DemographicGroup> demographicGroups = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "archiveData")
    private List<Event> events = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "archiveData")
    private List<StreamingService> streamingServices = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "archiveData")
    private List<Studio> studios = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "archiveData")
    private List<Offer> offers = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "archiveData")
    private List<WatchRecord> watchRecords = new ArrayList<>();

    public ArchiveData() {
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public List<DemographicGroup> getDemographicGroups() {
        return this.demographicGroups;
    }

    public void setDemographicGroups(List<DemographicGroup> demographicGroups) {
        this.demographicGroups = demographicGroups;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public List<StreamingService> getStreamingServices() {
        return streamingServices;
    }

    public void setStreamingServices(List<StreamingService> streamingServices) {
        this.streamingServices = streamingServices;
    }

    public List<Studio> getStudios() {
        return studios;
    }

    public void setStudios(List<Studio> studios) {
        this.studios = studios;
    }

    public List<Offer> getOffers() {
        return offers;
    }

    public void setOffers(List<Offer> offers) {
        this.offers = offers;
    }

    public List<WatchRecord> getWatchRecords() {
        return watchRecords;
    }

    public void setWatchRecords(List<WatchRecord> watchRecords) {
        this.watchRecords = watchRecords;
    }
}
